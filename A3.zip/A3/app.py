from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///assignment3.db'
app.config['SECRET_KEY'] = '992885fd8f9aedbb18a511ed05eef0793bce067f444de4ac6163d3b95b55473b'
app.config['PERMANENT_SESSION_LIFETIME']=timedelta(minutes=10)
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(10), nullable=False)  # 'student' or 'instructor'

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assignment = db.Column(db.String(50), nullable=False)
    mark = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(50), nullable=False)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    instructor_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    q1 = db.Column(db.Text, nullable=True)
    q2 = db.Column(db.Text, nullable=True)
    q3 = db.Column(db.Text, nullable=True)
    q4 = db.Column(db.Text, nullable=True)
    reviewed = db.Column(db.Text, nullable=False)

class RemarkRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assignment = db.Column(db.String(50), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(10), default='Pending')  # Pending, Approved, Rejected

@app.route('/')
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        role = request.form['role']
        user = User(username=username, password=password, role=role)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if 'name' in session:
                flash('Already logged in', 'error')
                return redirect(url_for('login'))
        
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and bcrypt.check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['role'] = user.role
            session['name']=username
            session.permanent=True
            if user.role == 'student':
                return redirect(url_for('student_home'))
            else:
                return redirect(url_for('instructor_home'))
        else:
            flash('Please check your login details and try again', 'error')
            return redirect(url_for('login'))
        
    return render_template('login.html')

@app.route("/home")
def home():
    if 'name' not in session:
        return redirect(url_for('register'))
    elif session['role'] != 'student':
        return redirect(url_for('instructor_home'))
    else:
        return redirect(url_for('student_home'))

@app.route("/logout")
def logout():
    session.pop('name', default=None)
    return redirect(url_for('login'))

@app.route('/syllabus')
def syllabus():
    return render_template("syllabus.html")

@app.route('/assignment')
def assignment():
    return render_template("assignment.html")

@app.route('/labs')
def labs():
    return render_template("labs.html")

@app.route('/lecturenotes')
def lecturenotes():
    return render_template("lecturenotes.html")

@app.route('/feedback')
def feedback():
    return render_template("feedback.html")

@app.route('/courseteam')
def courseteam():
    return render_template("courseteam.html")

@app.route('/student_home')
def student_home():
    user = User.query.get(session['user_id'])
    return render_template('student_home.html', user=user)

@app.route('/student_marks')
def student_marks():
    user = User.query.get(session['user_id'])
    grades = Grade.query.filter_by(student_id=user.id).all()

    return render_template('student_marks.html', user=user, grades=grades)

@app.route('/student_midterms')
def student_midterms():
    user = User.query.get(session['user_id'])
    grades = Grade.query.filter_by(student_id=user.id).all()

    return render_template('student_midterms.html', user=user, grades=grades)

@app.route('/student_labstutorials')
def student_labstutorials():
    user = User.query.get(session['user_id'])
    grades = Grade.query.filter_by(student_id=user.id).all()

    return render_template('student_labstutorials.html', user=user, grades=grades)

@app.route('/student_finals')
def student_finals():
    user = User.query.get(session['user_id'])
    grades = Grade.query.filter_by(student_id=user.id).all()

    return render_template('student_finals.html', user=user, grades=grades)

@app.route('/student_remark_requests')
def student_remark_requests():
    user = User.query.get(session['user_id'])
    remark_requests = RemarkRequest.query.filter_by(student_id=user.id).all()
    return render_template('student_remark_requests.html', remark_requests=remark_requests)

@app.route('/student_feedback')
def student_feedback():
    instructors = User.query.filter_by(role='instructor').all()
    return render_template('student_feedback.html', instructors=instructors)

@app.route('/request_remark', methods=['POST'])
def request_remark():
    if 'name' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
    
    assignment = request.form['assignment']
    reason = request.form['reason']
    remark_request = RemarkRequest(student_id=session['user_id'], assignment=assignment, reason=reason)
    db.session.add(remark_request)
    db.session.commit()

    flash('Remark request submitted successfully!')
    return redirect(url_for('student_marks'))

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    if 'name' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
    
    instructor_id = request.form['instructor_id']
    q1 = request.form['q1']
    q2 = request.form['q2']
    q3 = request.form['q3']
    q4 = request.form['q4']
    reviewed = 'false'
    feedback = Feedback(instructor_id=instructor_id, q1=q1, q2=q2, q3=q3, q4=q4, reviewed=reviewed)
    db.session.add(feedback)
    db.session.commit()

    flash('Remark request submitted successfully!')
    return redirect(url_for('student_feedback'))

@app.route('/instructor_home')
def instructor_home():
    user = User.query.get(session['user_id'])
    return render_template('instructor_home.html', user=user)

@app.route('/instructor_marks')
def instructor_marks():
    students = User.query.filter_by(role='student').all()
    grades = Grade.query.all()
    return render_template('instructor_marks.html', students=students, grades=grades)

@app.route('/instructor_feedback')
def instructor_feedback():
    user = User.query.get(session['user_id'])
    feedbacks = Feedback.query.all()
    return render_template('instructor_feedback.html', user=user, feedbacks=feedbacks)

@app.route('/instructor_remark_requests')
def instructor_remark_requests():
    remark_requests = RemarkRequest.query.all()
    return render_template('instructor_remark_requests.html', remark_requests=remark_requests)

@app.route('/instructor_reviewed', methods=['POST'])
def instructor_reviewed():
    if 'name' not in session or session['role'] != 'instructor':
        return redirect(url_for('login'))
    feedbacks = Feedback.query.all()

    id = int(request.form['id'])-1
    feedback = feedbacks[id]
    feedback.reviewed = 'true'
    db.session.commit()
    
    return redirect(url_for('instructor_feedback'))

@app.route('/update_mark', methods=['POST'])
def update_mark():
    if 'name' not in session or session['role'] != 'instructor':
        return redirect(url_for('login'))
    
    grades = Grade.query.all()

    id = int(request.form['id'])-1
    mark = request.form['mark']
    grade = grades[id]
    grade.mark = mark
    db.session.commit()

    flash('Marks updated successfully!')
    return redirect(url_for('instructor_marks'))

@app.route('/submit_remark', methods=['POST'])
def submit_remark():
    if 'name' not in session or session['role'] != 'instructor':
        return redirect(url_for('login'))
    
    remark_requests = RemarkRequest.query.all()
    id = int(request.form['id'])-1
    status = request.form['status']
    remark_request = remark_requests[id]
    remark_request.status = status
    db.session.commit()

    return redirect(url_for('instructor_remark_requests'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
