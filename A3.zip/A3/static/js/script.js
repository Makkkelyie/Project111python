document.addEventListener("DOMContentLoaded", function () {
    const remarkForms = document.querySelectorAll(".remark-form");
  
    remarkForms.forEach((form) => {
      form.addEventListener("submit", async function (e) {
        e.preventDefault();
        const formData = new FormData(form);
  
        const response = await fetch("/request_remark", {
          method: "POST",
          body: formData,
        });
  
        if (response.ok) {
          form.querySelector(".remark-msg").textContent = "✅ Remark submitted!";
          form.reset();
        } else {
          form.querySelector(".remark-msg").textContent = "❌ Failed to submit.";
        }
      });
    });
  });
  